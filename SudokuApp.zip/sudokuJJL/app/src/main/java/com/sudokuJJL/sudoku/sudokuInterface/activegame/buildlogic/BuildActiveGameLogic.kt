package com.sudokuJJL.sudoku.sudokuInterface.activegame.buildlogic

import android.content.Context
import com.sudokuJJL.sudoku.sudokuPlugins.ProductionDispatcherProvider
import com.sudokuJJL.sudoku.sudokuSettings.*
import com.sudokuJJL.sudoku.sudokuInterface.activegame.ActiveGameContainer
import com.sudokuJJL.sudoku.sudokuInterface.activegame.ActiveGameLogic
import com.sudokuJJL.sudoku.sudokuInterface.activegame.ActiveGameViewModel


internal fun buildActiveGameLogic(
    container: ActiveGameContainer,
    viewModel: ActiveGameViewModel,
    context: Context
): ActiveGameLogic {
    return ActiveGameLogic(
        container,
        viewModel,
        GameRepositoryImpl(
            LocalGameStorageImpl(context.filesDir.path),
            LocalSettingsStorageImpl(context.settingsDataStore)
        ),
        LocalStatisticsStorageImpl(
            context.statsDataStore
        ),
        ProductionDispatcherProvider
    )
}