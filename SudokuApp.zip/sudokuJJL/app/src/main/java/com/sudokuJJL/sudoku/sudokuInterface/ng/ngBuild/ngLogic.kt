package com.sudokuJJL.sudoku.sudokuInterface.ng.ngBuild

import android.content.Context
import com.sudokuJJL.sudoku.sudokuPlugins.ProductionDispatcherProvider
import com.sudokuJJL.sudoku.sudokuSettings.*
import com.sudokuJJL.sudoku.sudokuInterface.ng.NewGameContainer
import com.sudokuJJL.sudoku.sudokuInterface.ng.NewGameLogic
import com.sudokuJJL.sudoku.sudokuInterface.ng.NewGameViewModel

internal fun buildNewGameLogic(
    container: NewGameContainer,
    viewModel: NewGameViewModel,
    context: Context
): NewGameLogic {
    return NewGameLogic(
        container,
        viewModel,
        GameRepositoryImpl(
            LocalGameStorageImpl(context.filesDir.path),
            LocalSettingsStorageImpl(context.settingsDataStore)
        ),
        LocalStatisticsStorageImpl(
            context.statsDataStore
        ),
        ProductionDispatcherProvider
    )
}