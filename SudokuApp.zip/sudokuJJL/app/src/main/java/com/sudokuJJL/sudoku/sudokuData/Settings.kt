package com.sudokuJJL.sudoku.sudokuData

data class Settings(
    val difficulty: Difficulty,
    val boundary: Int,
)