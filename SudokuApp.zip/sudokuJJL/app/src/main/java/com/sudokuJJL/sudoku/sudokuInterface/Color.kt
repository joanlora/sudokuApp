package com.sudokuJJL.sudoku.sudokuInterface

import androidx.compose.ui.graphics.Color

val grey = Color(0XFF3f4246)
val black = Color(0xFF000000)
val skyBlue = Color(0xFF8ccfff)
val textLM = Color(0xDCFFFFFF)
val textDM = textLM
val gridLines = skyBlue
val tileBackgroundDM = textLM
val tileBackgroundLM = grey
val buttonsLM = Color(0xFF299fff)
val buttonsDM = buttonsLM