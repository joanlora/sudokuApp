package com.sudokuJJL.sudoku.sudokuInterface.ng

import com.sudokuJJL.sudoku.sudokuData.Settings
import com.sudokuJJL.sudoku.sudokuData.UserStatistics

class NewGameViewModel {

    internal lateinit var settingsState: Settings
    internal lateinit var statisticsState: UserStatistics
    internal var loadingState: Boolean = true
        set(value) {
            field = value
            subLoadingState?.invoke(field)
        }

    internal var subLoadingState: ((Boolean) -> Unit)? = null
}