package com.sudokuJJL.sudoku.sudokuPlugins

import kotlinx.coroutines.Job

abstract class BaseLogic<Joan>  {
    protected lateinit var jobTracker: Job
    abstract fun onEvent(Joan: Joan)
}