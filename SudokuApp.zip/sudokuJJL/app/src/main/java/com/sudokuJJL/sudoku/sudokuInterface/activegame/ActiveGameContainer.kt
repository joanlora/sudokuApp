package com.sudokuJJL.sudoku.sudokuInterface.activegame

interface ActiveGameContainer {
    fun showError()
    fun onNewGameClick()
}