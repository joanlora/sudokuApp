package com.sudokuJJL.sudoku.sudokuInterface.ng

interface NewGameContainer {
    fun showError()
    fun onDoneClick()
}